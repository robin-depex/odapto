Login box in other panel
Login Details Report
Leave Request in other panel
HR Module troughout testing 
Change Password check in other panel - student and parent can change username
student counting of active student in dashboard
dashboard chart view for admin, accountant