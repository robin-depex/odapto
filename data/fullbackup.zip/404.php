<style>
.chili{
  background:#FFF;
  margin-top:50px;
  border-radius:4px;
  }
 .chili h1{
	 font-size:80px;}
  
</style>
<div class="container">
  <div class="row">
    <div class="col-sm-12 parent text-center">
       <div class="col-sm-6 col-sm-offset-3 chili">
         <h1>404</h1>
         <h3>OOPS! PAGE NOT FOUND</h3>
         <a href="#">Back</a>
         
        </div>
    </div>
  </div>   
</div>
  