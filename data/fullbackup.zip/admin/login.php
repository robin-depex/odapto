<div class="content">
<div class="container-fluid">

<div class="col-sm-4 col-sm-offset-4" style="margin-top:150px;">

<div class="alert alert-warning alert-dismissable" style="display: none;">
  <a href="#" class="close" data-dismiss="alert" aria-label="close" style="margin-right: 10px;">&times;</a>
  <span class="result"></span>
</div>

<div class="card">
<div class="card-header" data-background-color="purple">
<h4 class="title">Admin Login</h4>
</div>
<div class="card-content">
<form action="" method="post" autocomplete="off">
    <div class="row">
       
        <div class="col-md-12">
			<div class="form-group label-floating">
				<label class="control-label">Email address</label>
				<input type="email" id="username" name="username" class="form-control" >
			</div>
        </div>
    </div>

     <div class="row">
       
        <div class="col-md-12">
			<div class="form-group label-floating">
				<label class="control-label">Password</label>
				<input type="password" id="password" name="password" class="form-control">
			</div>
        </div>
    </div>

  

    <button type="button" class="btn btn-primary pull-right" id="login" value="Login">Login Now</button>
    <div class="clearfix"></div>
</form>
</div>
</div>
</div>
</div>
</div>