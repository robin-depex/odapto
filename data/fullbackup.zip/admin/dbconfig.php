<?php  
require_once('DBInterface.php');
$db = new Database();
$db->connect();
?>