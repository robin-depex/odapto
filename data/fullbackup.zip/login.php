<?php include("inc/header_1.php"); ?>

  <div class="container" style="min-height: 490px;">
   <div class="row">
     <div class="col-sm-8 col-sm-offset-2" style="margin-top: 80px">
       <div class="col-sm-12">
          <h2 class="modal-title text-center"><strong><strong>Log in to Odapto</strong></h2>
        </div>
        <div class="modal-body">

          <form action="" method="post" id="loginForm" autocomplete="off">   
           <div class="form-group">
             <label>Email</label>
           <span><input type="text" id="username" name="username" class="form-control input-lg" placeholder="Someone@mail.com"></span>
           </div>
           <div class="form-group">
             <label>Password</label>
           <span><input type="password" id="password" name="password" class="form-control input-lg" placeholder="**********"></span>
           </div>
           <div class="form-group">

           <span>
           <input type="button" id="login" value="Login"  class="btn btn-danger">
           </span>

           <div class="col-sm-12 n-p reset top"><a href="forgotpassword.php" style="color: #000">Forgot your password? </a></div>
           </div>
           <div class="col-sm-12 top n-p" style="">
             <!-- google plus -->
             <p style="color:gray;display: none;"><strong>Did you sign up with your Google Account?</strong></p>
             <!-- facebook -->
             <div class="col-sm-6 n-p"><a style="color:#343f7b;" class="fb"  href="fbconfig.php" scope="public_profile,email"><img src="/images/loginfacebook.png" style="width:260px;"></a> </div>
             <!-- linked in -->
             <div class="col-sm-6 n-p"><a style="color: #008080;display: none;" class="linkedin" href="#">Log in width Linkedin</a> </div>
             
           </div>
           <div class="col-lg-12 boto n-p top">
              <span class=""><h3>Don't have an account? <a style="color: #f47442;" href="signup.php">create an Odapto account</a>
               </h3>
              </span>
             </div>
             </form>
            <!-- <fb:login-button scope="public_profile,email" onlogin="checkLoginState();">
            </fb:login-button> -->
            <div id="status">
            </div>
        </div>
      </div>
      
    </div>
  </div>

</body>

<script type="text/javascript">

function isValidEmailAddress(emailAddress) {
    var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        return expr.test(emailAddress);
}

  jQuery(document).ready(function($) {

$("#login").click(function(){

  var username = $("#username").val();
  var pass = $("#password").val();
   if(username == ""){
        $(".confirmBox").css({'display':'block',"position":'fixed','top':'10px','height':'50px'});
        $(".yes,.No").hide();
        $(".message").html("Please Enter Email Id").delay(3000).css({'fontSize':'16px','textAlign':'left','marginLeft':'15px','marginTop':'15px','fontWeight':'normal'});
        setTimeout(function() {
          $('.confirmBox').fadeOut('fast');
        }, 2000);
        event.preventDefault();
    }else if(!isValidEmailAddress(username)){
          $(".confirmBox").css({'display':'block',"position":'fixed','top':'10px','height':'50px'});
          $(".yes,.No").hide();
          $(".message").html("Please Enter Valid Email Id").delay(3000).css({'fontSize':'12px','textAlign':'left','marginLeft':'15px','marginTop':'15px','fontWeight':'normal','width':'480px'});
          setTimeout(function() {
            $('.confirmBox').fadeOut('fast');
          }, 2000);
          event.preventDefault();
      }else if(pass == ""){
        $(".confirmBox").css({'display':'block',"position":'fixed','top':'10px','height':'50px'});
        $(".yes,.No").hide();
        $(".message").html("Please Enter Password").delay(3000).css({'fontSize':'16px','textAlign':'left','marginLeft':'15px','marginTop':'15px','fontWeight':'normal'});
        setTimeout(function() {
          $('.confirmBox').fadeOut('fast');
        }, 2000);
        event.preventDefault();
    }else{
        var data = $("#loginForm").serialize();
       // alert(data);  
        $.ajax({
        url: "getLoginResponse.php",
        type: "POST",
        data: data,
        success: function(rel){
         // alert(rel);
          var obj = jQuery.parseJSON(rel);
          if(obj.result=="TRUE")
          {
            window.location.href = "<?php echo 'dashboard.php?page=home' ?>";
          }else if(obj.result=="FALSE"){ 
            $(".confirmBox").css({'display':'block',"position":'fixed','top':'10px','height':'50px'});
            $(".yes,.No").hide();
            $(".message").html(obj.message);
            setTimeout(function() {
              $('.confirmBox').css({'display':'block'});
            }, 2000);
          }
        }
      });        
      return false; 
    }

});
  
});
</script>


</html>
