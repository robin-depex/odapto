<td class="content-main hidenavlayer">

<table border="0" cellpadding="3" cellspacing="0" class="tabelle1" width="100%">
<tr><td class="bigtitel"><table style="line-height: 12px; padding: 3px; padding-left: 0px;" border="0" cellpadding="0" cellspacing="0" width="100%"><tr>
        <td class="bigtitel">Help.</td>
        <td width="140" style="font-weight: bold; text-align: right;"><a href="<?php echo EMP_URL;?>index.php?page=help">Do you need help?</a></td></tr></table></td></tr>
</table>
<script type="text/javascript">
<!--
function show_alternative_email() {
if (document.getElementById('act_alternative_email').checked == true) {
document.getElementById('alternative_email_show').style.display='block';
}
else {
document.getElementById('alternative_email_show').style.display='none';
}
}
//-->
</script>

<form method="POST" action="hpm_login.php" name="formular" style="margin:0px;">

<table border="0" cellpadding="3" cellspacing="0" class="tabelle1" width="100%">
<tr>
  <td class="titel" colspan="2">&nbsp;</td>
</tr>
<tr>
<td width="85" align="right">. </td>
<td width="1203">1. This area belong to help the user.</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
</table>


<table border="0" cellpadding="3" cellspacing="0" class="tabelle1" width="100%"><tr>
  <td>&nbsp;</td>
</tr></table>
</form>

<script type="text/javascript" src="http://count.asnetworks.de/count.js">
</script>
<script type="text/javascript">
asn_site_id = "95";
asn_zone_id = "2";
asn_no_referrer = "hpage.com, de.to";
Track();
</script></td>