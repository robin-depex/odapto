<span id='cwppButton'></span>
<script src='https://www.paypalobjects.com/js/external/connect/api.js'></script>
<script>
paypal.use( ['login'], function (login) {
  login.render ({
    "appid":"AT3HHq7K2jOyCpqKVG-_ac0KufvGrrNyQmWFwYxNvwM6Yguvi1yroG3nWeiWClTT9c8MCixC_DsPWLhz",
    "authend":"sandbox",
    "scopes":"openid",
    "containerid":"cwppButton",
    "responseType":"code",
    "locale":"en-us",
    "buttonType":"CWP",
    "buttonShape":"pill",
    "buttonSize":"lg",
    "fullPage":"true",
    "returnurl":"https://www.okeyclick.com/api/braintree/public_html/live_return_url.php"
  });
});
</script>


<!--connect -->
<!--<span id='cwppButton'></span>
<script src='https://www.paypalobjects.com/js/external/connect/api.js'></script>
<script>
paypal.use( ['login'], function (login) {
  login.render ({
    "appid":"AT3HHq7K2jOyCpqKVG-_ac0KufvGrrNyQmWFwYxNvwM6Yguvi1yroG3nWeiWClTT9c8MCixC_DsPWLhz",
    "authend":"sandbox",
    "scopes":"email address profile",
    "containerid":"cwppButton",
    "responseType":"code",
    "locale":"en-us",
    "buttonType":"CWP",
    "buttonShape":"pill",
    "buttonSize":"lg",
    "fullPage":"true",
    "returnurl":"https://www.okeyclick.com/api/braintree/public_html/live_return_url.php?user_id=11"
  });
});
</script>-->
<br>
<a href="https://www.sandbox.paypal.com/connect/?flowEntry=static&client_id=AT3HHq7K2jOyCpqKVG-_ac0KufvGrrNyQmWFwYxNvwM6Yguvi1yroG3nWeiWClTT9c8MCixC_DsPWLhz&response_type=code&scope=openid&redirect_uri=https%3A%2F%2Fwww.okeyclick.com/api/braintree/public_html/live_return_url.php&state=12">
check
</a>