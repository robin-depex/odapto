<div class="section" id="section0">
    <header class="wow fadeInDown" id="header">
  <div class="container">
     <div class="row">
       <div class="col-sm-12">
         <div class="col-sm-6"><img src="images/logo.png" class="img-responsive" /></div>
          <div class="col-sm-6">
            <ul class="list-inline pull-right bttn"><li><h4 class="en">EN <span class="caret"></h4></li>
               <li>
               <a href="login.php" class="btn btn-danger">LogIn.</a></li>
                <li>
                 <a href="signup.php" class="btn btn-primary">Sign Up</a></li>
            </ul>
          </div>
       </div>
       
<div class="pos">
<div class="col-lg-12 animated fadeInDown delay-02" data-animation="fadeInDown" data-animation-delay="02">
         <h2>Odapto lets you work more</h2>
<h2>collaboratively and get more done.</h2>
</div>
<div class="col-lg-12  animated fadeInDown delay-03" data-animation="fadeInDown" data-animation-delay="03">
<h4>Odapto boards, lists, and cards enable you to organize and prioritize
your projects in a fun, flexible and rewarding way. </h4>
</div>
<div class="clearfix"></div>
<div class="col-lg-6 col-lg-offset-3 text-center top  animated fadeInDown delay-04" data-animation="fadeInDown" data-animation-delay="04">
       <a href="signup.php" class="btn btn-primary">Sign Up – It’s Free.</a>
       </div>
       <div class="clearfix"></div>
       <h3 class="top  animated fadeInDown delay-05" data-animation="fadeInDown" data-animation-delay="05">Already use Odapto? <a href="login.php">Log in</a>.</h3>
       </div>
       
     </div>
  </div>
</header>

  </div>