<?php 
include("inc/header.php"); 

include("inc/menu.php");
include("inc/main-content.php");
include("inc/footer.php"); 


?>